-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: board_adv
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `USER_SEQ` int NOT NULL AUTO_INCREMENT,
  `USER_NAME` varchar(100) NOT NULL,
  `USER_PASSWORD` varchar(50) NOT NULL,
  `USER_EMAIL` varchar(100) NOT NULL,
  `USER_PROFILE_IMAGE_URL` varchar(500) DEFAULT '/img/maru.jpg',
  `USER_REGISTER_DATE` date DEFAULT NULL,
  `user_clsf` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`USER_SEQ`),
  UNIQUE KEY `USER_EMAIL_UNIQUE` (`USER_EMAIL`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'홍길동','1234','hong@gildong.com','/img/maru.jpg',NULL,NULL),(2,'손흥민 ','1234','son@son.com','','2022-10-25',NULL),(8,'김싸피','1234','kim@ssafy.com','','2022-10-25',NULL),(10,'이싸피','qwer1234!','lee@ssafy.com','','2022-10-25',NULL),(11,'test1','qwer1234!','test1@test.com','','2022-10-25',NULL),(12,'admin','1234','hacker','','2022-10-25',NULL),(13,'작은아씨들악','1234','yeom@yeom.com','','2022-10-25',NULL),(14,'장시우','1234','siu@jang.com1111111111','','2022-10-25',NULL),(15,'장시우','1234','siu@jang.com','','2022-10-25',NULL),(16,'장시우','1234','siu@jang.com1','','2022-10-25',NULL),(17,'장시우','1234','siu@jang.com12','','2022-10-25',NULL),(18,'장시우','1234','siu@jang.com123','','2022-10-25',NULL),(19,'장시우','1234','siu@jang.com1234','','2022-10-25',NULL),(20,'장시우','1234','siu@jang.com12345','','2022-10-25',NULL),(21,'장시우','1234','siu@jang.com123456','','2022-10-25',NULL),(22,'장시우','1234','siu@jang.com1234567','','2022-10-25',NULL),(23,'장시우','1234','siu@jang.com12345678','','2022-10-25',NULL),(24,'장시우','1234','siu@jang.com123456789','','2022-10-25',NULL),(25,'장시우','1234','siu@jang.com1234567891','','2022-10-25',NULL),(26,'장시우','1234','siu@jang.com12345678911','','2022-10-25',NULL),(27,'장시우','1234','siu@jang.com123456789111','','2022-10-25',NULL),(28,'장시우','1234','siu@jang.com1234567891111','','2022-10-25',NULL),(29,'장시우','1234','siu@jang.com12345678911111','','2022-10-25',NULL),(30,'장시우','1234','siu@jang.com123456789111111','','2022-10-25',NULL),(31,'권혁근','1234','hong@hong.com','../img/noProfile.png',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-15 16:16:33
