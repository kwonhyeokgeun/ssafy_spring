-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: board_adv
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board_file`
--

DROP TABLE IF EXISTS `board_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_file` (
  `FILE_ID` int NOT NULL AUTO_INCREMENT,
  `BOARD_ID` int NOT NULL,
  `FILE_NAME` varchar(500) NOT NULL,
  `FILE_SIZE` int NOT NULL,
  `FILE_CONTENT_TYPE` varchar(500) NOT NULL,
  `FILE_URL` varchar(500) NOT NULL,
  `REG_DT` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`FILE_ID`),
  KEY `BOARD_FILE_FK_idx` (`BOARD_ID`),
  CONSTRAINT `BOARD_FILE_FK` FOREIGN KEY (`BOARD_ID`) REFERENCES `board` (`BOARD_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_file`
--

LOCK TABLES `board_file` WRITE;
/*!40000 ALTER TABLE `board_file` DISABLE KEYS */;
INSERT INTO `board_file` VALUES (8,3251,'maru.jpg',21132,'image/jpeg','upload/d01271dd-05ea-4470-91ae-34994698ca2e.jpg','2022-10-28 09:43:11'),(13,3260,'maru (1).jpg',21132,'image/jpeg','upload/fa44f3d7-c2b7-457a-b1a4-1ef7619d77c9.jpg','2022-10-28 11:38:27'),(14,3269,'캡처1.PNG',1918678,'image/png','upload/d7f68694-eb94-4333-b785-a1a59ec47ab9.PNG','2022-11-14 17:58:50'),(17,3270,'캡처2.PNG',1823571,'image/png','upload/966f27e2-c75d-4ae1-a5a0-cc1dc528f17e.PNG','2022-11-15 10:49:02'),(18,3270,'캡처3.PNG',1860949,'image/png','upload/e0271066-5fa1-4118-8c8e-b1fbf50b57f2.PNG','2022-11-15 10:49:02');
/*!40000 ALTER TABLE `board_file` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-15 16:16:33
