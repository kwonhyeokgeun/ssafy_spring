package com.mycom.myapp.calc.all;

public interface Calculator {
	public int add(int n1, int n2);
	
}
