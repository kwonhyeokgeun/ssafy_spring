package com.mycom.myapp.calc.configuration;



//어노테이션없음
public class Calculator {
	public int add(int n1, int n2) {
		return n1+n2;
	}
}
